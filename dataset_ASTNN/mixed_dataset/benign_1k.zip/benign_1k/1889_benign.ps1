

 -||-> if ( -||-> Get-Command Get-SmbShare -ErrorAction SilentlyContinue <-||- ) {
     -||-> Get-SmbShare <-||- 
} <-||- 

