
 -||-> task TaskAFromModuleB {
     -||-> 'Executing [TaskA] from module [TaskModuleB] version [0.1.0]' <-||- 
} <-||- 

 -||-> task TaskBFromModuleB {
     -||-> 'Executing [TaskB] from module [TaskModuleB] version [0.1.0]' <-||- 
} <-||- 


