
 -||-> $global:FunctionHelpTestExceptions = @(
     -||-> 'Get-PSFScriptblock' <-||- 
) <-||- 


 -||-> $global:HelpTestEnumeratedArrays = @(
	 -||-> "PSFramework.License.ProductType[]",
	"PSFramework.Message.MessageLevel[]" <-||- 
) <-||- 


 -||-> $global:HelpTestSkipParameterType = @{
    
} <-||- 


