
 -||-> Connect-PnPOnline -Url https://yourtenant.sharepoint.com <-||-  



 -||-> $creds =  -||-> Get-Credential <-||-  <-||- 
 -||-> Connect-PnPOnline -Url https://yourtenant.sharepoint.com -Credentials $creds <-||- 



 -||-> Connect-PnPOnline -Url https://yourtenant.sharepoint.com -Credentials "LABEL" <-||- 


 -||-> Connect-PnPOnline -Url https://yourtenant.sharepoint.com -AppId e8a9a0ef-86a9-4871-ba5f-dbacbcd57e4c -AppSecret abmQDEw/x/PHX6stdhbJgDEF3pSZkN64sS63XDViBm60= <-||- 














 -||-> Connect-PnPOnline -Url https://yourtenant.sharepoint.com -AppId e8a9a0ef-86a9-4871-ba5f-dbacbcd57e4c -AppSecret abmQDEw/x/PHX6stdhbJgDEF3pSZkN64sS63XDViBm60= -Realm 939013d2-9450-4a4e-a63a-3f364233c6cd <-||- 



