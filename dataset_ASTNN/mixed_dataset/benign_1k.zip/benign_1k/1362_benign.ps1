 -||-> function Get-HelpMessage
{
    
    [CmdletBinding()]
    [Alias('HelpMsg')]
    PARAM($Id)
     -||-> [ComponentModel.Win32Exception] $id <-||- 
} <-||- 

