
[CmdletBinding()]
Param (
)






 -||-> [string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt' <-||- 
 -||-> [string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions' <-||- 
 -||-> [version]$appDeployExtScriptVersion = [version]'3.8.0' <-||- 
 -||-> [string]$appDeployExtScriptDate = '23/09/2019' <-||- 
 -||-> [hashtable]$appDeployExtScriptParameters = $PSBoundParameters <-||- 















 -||-> If ( -||-> $scriptParentPath <-||- ) {
	 -||-> Write-Log -Message "Script [$( -||-> $MyInvocation.MyCommand.Definition <-||- )] dot-source invoked by [$( -||-> ( -||-> ( -||-> Get-Variable -Name MyInvocation <-||- ).Value <-||- ).ScriptName <-||- )]" -Source $appDeployToolkitExtName <-||- 
} Else {
	 -||-> Write-Log -Message "Script [$( -||-> $MyInvocation.MyCommand.Definition <-||- )] invoked directly" -Source $appDeployToolkitExtName <-||- 
} <-||- 






