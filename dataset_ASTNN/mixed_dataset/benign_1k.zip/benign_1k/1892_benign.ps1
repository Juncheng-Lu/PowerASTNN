
 -||-> Get-WmiObject Win32_Product <-||- 

