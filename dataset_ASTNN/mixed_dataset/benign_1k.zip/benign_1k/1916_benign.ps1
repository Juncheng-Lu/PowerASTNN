

 -||-> if ( -||-> Get-Command Get-SmbSession -ErrorAction SilentlyContinue <-||- ) {
     -||-> Get-SmbSession <-||- 
} <-||- 

