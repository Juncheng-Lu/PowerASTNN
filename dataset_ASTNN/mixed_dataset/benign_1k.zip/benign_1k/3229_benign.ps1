 -||-> workflow Test-WorkFlowWithVariousParameters
{
	param([string] $a, [int] $b, [DateTime] $c)
             -||-> "a  is " + $a <-||-  
             -||-> "b  is " + $b <-||-  
             -||-> "c  is " + $c <-||-  
} <-||- 

