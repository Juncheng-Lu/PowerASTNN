
 -||-> . 'C:\Program Files\Microsoft\Exchange Server\V14\bin\RemoteExchange.ps1' <-||- 

 -||-> Connect-ExchangeServer -auto <-||- 



 -||-> Get-MailBox -Identity USERNAME <-||- 




