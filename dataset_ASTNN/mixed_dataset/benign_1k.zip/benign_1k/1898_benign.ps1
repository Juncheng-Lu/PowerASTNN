
 -||-> Get-HotFix | Select-Object HotfixID, Caption, Description, InstalledBy <-||- 

