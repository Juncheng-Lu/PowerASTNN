


class Event {
    [string]$Type
    [string]$ChannelId
    [pscustomobject]$Data
}



