 -||-> Invoke-Expression ( -||-> New-Object -TypeName Net.WebClient <-||- ).DownloadString('https://raw.githubusercontent.com/officedev/PnP-PowerShell/master/Samples/Modules.Install/Install-PowerShellPackageMangement.ps1') <-||-  
 -||-> Invoke-Expression ( -||-> New-Object -TypeName Net.WebClient <-||- ).DownloadString('https://raw.githubusercontent.com/officedev/PnP-PowerShell/master/Samples/Modules.Install/Install-SharePointPnPPowerShellHelperModule.ps1') <-||- 

