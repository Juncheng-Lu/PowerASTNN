

 -||-> schtasks /query /FO CSV /v | ConvertFrom-Csv <-||- 


