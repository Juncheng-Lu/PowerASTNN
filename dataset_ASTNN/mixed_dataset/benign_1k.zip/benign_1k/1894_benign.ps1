
 -||-> Get-WmiObject -Namespace root\Microsoft\SecurityClient -Class AntimalwareInfectionStatus <-||- 

