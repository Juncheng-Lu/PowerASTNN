Configuration ContosoDscConfiguration {

    Node "TEST-PC1" {
        WindowsFeature MyFeatureInstance {
            Ensure =  -||-> "Present" <-||- 
            Name =   -||-> "RSAT" <-||- 
        }
        WindowsFeature My2ndFeatureInstance {
            Ensure =  -||-> "Present" <-||- 
            Name =  -||-> "Bitlocker" <-||- 
        }
    }
} 

 -||-> ContosoDscConfiguration <-||- 

