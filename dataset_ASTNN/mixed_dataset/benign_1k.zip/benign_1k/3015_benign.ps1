param(
    [string]$first,
    [string]$second
)
 -||-> Write-Host This is a sample script with parameters $first $second <-||- 
 -||-> Write-Host "Second line with escaped characters" <-||- 


