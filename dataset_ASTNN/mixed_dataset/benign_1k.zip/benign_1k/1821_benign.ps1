
 -||-> Function Verb-Noun {

	[CmdletBinding()]
	Param (
	)
	
	Begin {
		
		 -||-> [string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name <-||- 
		 -||-> Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header <-||- 
	}
	Process {
		 -||-> Try {
			
		}
		Catch {
			 -||-> Write-Log -Message "<error message>. `n$( -||-> Resolve-Error <-||- )" -Severity 3 -Source ${CmdletName} <-||- 
		} <-||- 
	}
	End {
		 -||-> Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer <-||- 
	}
} <-||- 

