
 -||-> Get-WmiObject -namespace root\Microsoft\SecurityClient -Class AntimalwareHealthStatus <-||- 

