

 -||-> Update-TypeData -TypeName System.Diagnostics.Process -SerializationDepth 3 -Force <-||- 
 -||-> Get-Process <-||- 

